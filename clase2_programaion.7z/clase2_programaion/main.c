#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
int main()
{
    //PASAR PARCIAL DE JavaS a C
 /*char nombre[20];
 char localidad[20];

 printf("ingrese nombre:");
 gets(nombre);

 printf("ingrese localidad:");
 gets(localidad);

 printf("usted se llama: %s y vive en la localidad de %s", nombre, localidad);*/



 /*float precio;
 int precioPorDescuento;
 float descuento;
 float iva;
 float preciofinal;




 printf("ingrese precio:\n");
 scanf("%f", &precio);
 printf("ingrese descuento:\n");
 scanf("%d", &precioPorDescuento);



 descuento= precio * precioPorDescuento / 100;

 precioPorDescuento= precio - descuento;

 iva = precioPorDescuento * 21;

 preciofinal= precioPorDescuento + iva;




 printf("el precio ingresado es: %.2f y el descuento total es: %.2f", precio, descuento);

 printf("\nel precio por descuento es: %d", precioPorDescuento);

 printf("\n el precio a pagar es: %.2f", preciofinal);*/


 /*int num1;
 int num2;
 float resultado;

 printf("numero:");
 scanf("%d", &num1);

 printf("otro numero:");
 scanf("%d", &num2);

 if(num1 == num2)
 {
     printf("los numeros concatenados son: %.2f%.2f", num1, num2);
 }
 else if(num1 > num2)
 {
     if(num2 !=0)
     {
       resultado= (float) num1 / num2;
       printf("el resultado de la division es: %.2f", resultado);
     }
     else
     {
         printf("NO SE PUEDE DIVIDIR POR CERO");
     }

 }
 else
 {
   resultado = num1 + num2;
   printf("la suma de los numeros es: %.2f", resultado);

   if (resultado < 50)
   {
       printf("y es menor a 50");
   }


 }*/

/*realizar el algoritmo que permita el ingreso por promt de las notas(validar 0 y 10), la edad y el sexo (validar f/m)*/

 int notas;
 int edad;
  char sexo;
  int i;

  for(i=0;i<5;i++)
  {
      printf("ingrese nota: ");
      scanf("%d", &notas);
      while(notas !=0 || notas !=10)
      {
          printf("la nota ingresada es invalida, reingresar");
          scanf("%d", &notas);
      }
      printf("ingrese edad:");
      scanf("%d", &edad);
      while(edad <0)
      {
          printf("la edad no es correcta, reingresar:");

           scanf("%d", &edad);
      }

      printf("ingrese sexo:");
      scanf("%c", &sexo);
      sexo= tolower(sexo);


      while(sexo != 'f' || sexo != 'm')
      {
          printf("sexo incorrecto, reingresar:\n");
          scanf("%c", &sexo);
      }
  }


printf("las notas ingresadas son: %d\n", notas);
printf("las edades son: %d\n", edad);
printf("sexo: %c\n", sexo);

return 0;



}
