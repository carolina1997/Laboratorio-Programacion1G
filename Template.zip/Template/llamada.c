#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "llamada.h"
#include "utn.h"
#define QTY 10
#define OCUPADO 0
#define LIBRE 1

static int buscarLugarLibre(eLlamada* array_llamada,int limite);
static int proximoId();

int llamada_init(eLlamada* array_llamada,int limite)
{
    int retorno = -1;
    int i;
    if(limite > 0 && array_llamada != NULL)
    {
        retorno = 0;
        for(i=0;i<limite;i++)
        {
            array_llamada[i].isEmpty = 1;
        }
    }
    return retorno;
}

int llamada_buscarPorId(eLlamada* array_llamada,int limite, int id)
{
    int retorno = -1;
    int i;
    if(limite > 0 && array_llamada != NULL)
    {
        retorno = -2;
        for(i=0;i<limite;i++)
        {
            if(array_llamada[i].isEmpty == OCUPADO && array_llamada[i].idLlamada == id)
            {
                retorno = i;
                break;
            }
        }
    }
    return retorno;
}

int llamada_baja(eLlamada* array_llamada,int limite, int id)
{

    int retorno = -1;
    int indice;
    indice = llamada_buscarPorId(array_llamada,limite,id);
    if(indice >= 0)
    {
        retorno = 0;
        array_llamada[indice].isEmpty = LIBRE;
    }
    return retorno;
}


int llamada_mostrar(eLlamada* array_llamada,int limite)
{
    int retorno = -1;
    int i;
    if(limite > 0 && array_llamada != NULL)
    {
        retorno = 0;
        for(i=0;i<limite;i++)
        {
            if(!array_llamada[i].isEmpty)
            {
               printf("\n[RELEASE] %d - %d -%d - %d- %d - %d",array_llamada[i].idAbonado,array_llamada[i].idEstado,array_llamada[i].idMotivo,array_llamada[i].Tiempo,array_llamada[i].idLlamada,array_llamada[i].isEmpty);
            }
        }
    }
    return retorno;
}

int llamada_mostrarDebug(eLlamada* array_llamada,int limite)
{
    int retorno = -1;
    int i;
    if(limite > 0 && array_llamada != NULL)
    {
        retorno = 0;
        for(i=0;i<limite;i++)
        {
            printf("\n[RELEASE] %d - %d -%d - %d- %d - %d",array_llamada[i].idAbonado,array_llamada[i].idEstado,array_llamada[i].idMotivo,array_llamada[i].Tiempo,array_llamada[i].idLlamada,array_llamada[i].isEmpty);
        }
    }
    return retorno;
}


int llamada_alta(eLlamada* array_llamada,int limite)
{
    int retorno = -1;
    int idAbonado;
    int idMotivo;
    int idEstado;
    int Tiempo;
    int id;
    int indice;

    if(limite > 0 && array_llamada != NULL)
    {
        retorno = -2;
        indice = buscarLugarLibre(array_llamada,limite);
        if(indice >= 0)
        {
            retorno = -3;
            id = proximoId();
            if(!getValidInt("INGRESE NUMERO:","Error",Numero,0,500,2))
             {
                retorno = 0;

                array_llamada[indice].idLlamada = id;
                array_llamada[indice].isEmpty = OCUPADO;
            }
        }
    }
    return retorno;
}



int llamada_modificacion(eLlamada* array_llamada,int limite, int id)
{
    int retorno = -1;
    int indice;
    char nombre[50];
    indice = llamada_buscarPorId(array_llamada,limite,id);
    if(indice >= 0)
    {
        retorno = -2;
        if(!getValidString("Nombre?","Error","Overflow", nombre,50,2))
        {
            retorno = 0;
            strcpy(array_llamada[indice].nombre,nombre);
        }


    }
    return retorno;
}


static int buscarLugarLibre(eLlamada* array_llamada,int limite)
{
    int retorno = -1;
    int i;
    if(limite > 0 && array_llamada != NULL)
    {
        retorno = -2;
        for(i=0;i<limite;i++)
        {
            if(array_llamada[i].isEmpty == LIBRE)
            {
                retorno = i;
                break;
            }
        }
    }
    return retorno;
}


static int proximoId()
{
    static int ultimoId = -1;
    ultimoId++;
    return ultimoId;
}



int llamada_ordenar(eLlamada* array_llamada,int limite, int orden)
{
    int retorno = -1;
    int flagSwap;
    int i;
    eLlamada auxiliar;

    if(limite > 0 && array_llamada != NULL)
    {
        retorno = 0;
        do
        {
            flagSwap = 0;
            for(i=0;i<limite-1;i++)
            {
                    if(array_llamada[i].isEmpty == OCUPADO && array_llamada[i+1].isEmpty == OCUPADO )
                    {
                        if((strcmp(array_llamada[i].nombre,array_llamada[i+1].nombre) > 0 && !orden) || (strcmp(array_llamada[i].nombre,array_llamada[i+1].nombre) < 0 && orden)) //<------------
                        {
                            auxiliar = array_llamada[i];
                            array_llamada[i] = array_llamada[i+1];
                            array_llamada[i+1] = auxiliar;
                            flagSwap = 1;
                        }
                    }
            }
        }while(flagSwap);
    }

    return retorno;
}









































