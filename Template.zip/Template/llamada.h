#ifndef LLAMADA_H_INCLUDED
#define LLAMADA_H_INCLUDED

#define EN CURSO 0
#define SOLUCIONADO 1
#define NO_SOLUCIONADO 2

typedef struct
{
    char nombre[50];

    int idAbonado;
    int idMotivo;
    int idEstado;
    int Tiempo;
    //------------
    int idLlamada;
    int isEmpty;
}eLlamada;
#endif // LLAMADA_H_INCLUDED

int llamada_init(eLlamada* array,int limite);
int llamada_buscarPorId(eLlamada* array,int limite, int id);
int llamada_baja(eLlamada* array,int limite, int id);

int llamada_mostrar(eLlamada* array,int limite);
int llamada_mostrarDebug(eLlamada* array,int limite);
int llamada_alta(eLlamada* array,int limite);
int llamada_modificacion(eLlamada* array,int limite, int id);
int llamada_ordenar(eLlamada* array,int limite, int orden);



