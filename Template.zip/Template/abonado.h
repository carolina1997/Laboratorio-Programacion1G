#ifndef ABONADO_H_INCLUDED
#define ABONADO_H_INCLUDED
typedef struct
{
    char nombre[50];
    char Apellido[50];
    int Numero;
    int idAbonado;
    int isEmpty;
}eAbonado;
#endif // ABONADO_H_INCLUDED

int abonado_init(eAbonado* array,int limite);
int abonado_buscarPorId(eAbonado* array,int limite, int id);
int abonado_baja(eAbonado* array,int limite, int id);

int abonado_mostrar(eAbonado* array,int limite);
int abonado_mostrarDebug(eAbonado* array,int limite);
int abonado_alta(eAbonado* array,int limite);
int abonado_modificacion(eAbonado* array,int limite, int id);
//int abonado_ordenar(eAbonado* array,int limite, int orden);



