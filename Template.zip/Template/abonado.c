#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "abonado.h"
#include "utn.h"
#define QTY 10
#define OCUPADO 0
#define LIBRE 1

static int buscarLugarLibre(eAbonado* array_abonado,int limite);
static int proximoId();

int abonado_init(eAbonado* array_abonado,int limite)
{
    int retorno = -1;
    int i;
    if(limite > 0 && array_abonado != NULL)
    {
        retorno = 0;
        for(i=0;i<limite;i++)
        {
            array_abonado[i].isEmpty = 1;
        }
    }
    return retorno;
}

int abonado_buscarPorId(eAbonado* array_abonado,int limite, int id)
{
    int retorno = -1;
    int i;
    if(limite > 0 && array_abonado != NULL)
    {
        retorno = -2;
        for(i=0;i<limite;i++)
        {
            if(array_abonado[i].isEmpty == OCUPADO && array_abonado[i].idAbonado == id)
            {
                retorno = i;
                break;
            }
        }
    }
    return retorno;
}

int abonado_baja(eAbonado* array_abonado,int limite, int id)
{

    int retorno = -1;
    int indice;
    indice = abonado_buscarPorId(array_abonado,limite,id);
    if(indice >= 0)
    {
        retorno = 0;
        array_abonado[indice].isEmpty = LIBRE;
    }
    return retorno;
}


int abonado_mostrar(eAbonado* array_abonado,int limite)
{
    int retorno = -1;
    int i;
    if(limite > 0 && array_abonado != NULL)
    {
        retorno = 0;
        for(i=0;i<limite;i++)
        {
            if(!array_abonado[i].isEmpty)
            {
               printf("\n[RELEASE] %s - %s - %d- %d - %d",array_abonado[i].nombre,array_abonado[i].Apellido,array_abonado[i].Numero,array_abonado[i].idAbonado,array_abonado[i].isEmpty);
            }
        }
    }
    return retorno;
}

int abonado_mostrarDebug(eAbonado* array_abonado,int limite)
{
    int retorno = -1;
    int i;
    if(limite > 0 && array_abonado != NULL)
    {
        retorno = 0;
        for(i=0;i<limite;i++)
        {
             printf("\n[DEBUG] %s - %s - %d- %d - %d",array_abonado[i].nombre,array_abonado[i].Apellido,array_abonado[i].Numero,array_abonado[i].idAbonado,array_abonado[i].isEmpty);
        }
    }
    return retorno;
}


int abonado_alta(eAbonado* array_abonado,int limite)
{
    int retorno = -1;
    char nombre[50];
    char Apellido[50];
    int Numero;
    int id;
    int indice;

    if(limite > 0 && array_abonado != NULL)
    {
        retorno = -2;
        indice = buscarLugarLibre(array_abonado,limite);
        if(indice >= 0)
        {
            retorno = -3;
            id = proximoId();
            if(!getValidString("INGRESE NOMBRE:","Error","Overflow", nombre,50,2))
            {
                if(!getValidString("INGRESE APELLIDO:","Error","Overflow", Apellido,50,2))
                {
                  if(!getValidInt("INGRESE NUMERO:","Error",Numero,0,500,2))
                  {
                        retorno = 0;
                        strcpy(array_abonado[indice].nombre,nombre);
                        strcpy(array_abonado[indice].Apellido,Apellido);
                        array_abonado[indice].Numero = Numero;
                        array_abonado[indice].idAbonado = id;
                        array_abonado[indice].isEmpty = OCUPADO;
            }
        }
    }
    return retorno;
}



int abonado_modificacion(eAbonado* array_abonado,int limite, int id)
{
    int retorno = -1;
    int indice;
    char nombre[50];
    indice = abonado_buscarPorId(array_abonado,limite,id);
    if(indice >= 0)
    {
        retorno = -2;
        if(!getValidString("INGRESE NOMBRE","Error","Overflow", nombre,50,2))
        {
            retorno = 0;
            strcpy(array_abonado[indice].nombre,nombre);
        }


    }
    return retorno;
}


static int buscarLugarLibre(eAbonado* array_abonado,int limite)
{
    int retorno = -1;
    int i;
    if(limite > 0 && array_abonado != NULL)
    {
        retorno = -2;
        for(i=0;i<limite;i++)
        {
            if(array_abonado[i].isEmpty == LIBRE)
            {
                retorno = i;
                break;
            }
        }
    }
    return retorno;
}


static int proximoId()
{
    static int ultimoId = -1;
    ultimoId++;
    return ultimoId;
}



/*int abonado_ordenar(eAbonado* array_abonado,int limite, int orden)
{
    int retorno = -1;
    int flagSwap;
    int i;
    eAbonado auxiliar;

    if(limite > 0 && array_abonado != NULL)
    {
        retorno = 0;
        do
        {
            flagSwap = 0;
            for(i=0;i<limite-1;i++)
            {
                    if(array_abonado[i].isEmpty == OCUPADO && array_abonado[i+1].isEmpty == OCUPADO )
                    {
                        if((strcmp(array_abonado[i].nombre,array_abonado[i+1].nombre) > 0 && !orden) || (strcmp(array_abonado[i].nombre,array_abonado[i+1].nombre) < 0 && orden)) //<------------
                        {
                            auxiliar = array_abonado[i];
                            array_abonado[i] = array_abonado[i+1];
                            array_abonado[i+1] = auxiliar;
                            flagSwap = 1;
                        }
                    }
            }
        }while(flagSwap);
    }

    return retorno;
}
*/








































