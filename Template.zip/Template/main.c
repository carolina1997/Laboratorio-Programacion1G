#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include "abonado.h"
#include "llamada.h"
#include "utn.h"
#define QTY_ABONADO 100
#define QTY_LLAMADA 1000

int main()
{
    eAbonado array_abonado[QTY_ABONADO];
    eLlamada array_llamado[QTY_LLAMADA];
    int menu;
    int auxiliarId;

    abonado_init(array_abonado,QTY_ABONADO);
    do
    {
        getValidInt("\n1.Alta\n2.Baja\n3.Modificar\n4.Mostrar\n5.Ordenar\n6.Mostrar Debug\n9.Salir\n","\nNo valida\n",&menu,1,9,1);
        switch(menu)
        {
            case 1:
                abonado_alta(array_abonado,QTY_ABONADO);
                break;
            case 2:
                getValidInt("ID?","\nNumero valida\n",&auxiliarId,0,200,2);
                abonado_baja(array_abonado,QTY_ABONADO,auxiliarId);
                break;
            case 3:
                getValidInt("ID?","\nNumero valida\n",&auxiliarId,0,200,2);
                abonado_modificacion(array_abonado,QTY_ABONADO,auxiliarId);
                break;
            case 4:
                //fantasma_mostrar(array,QTY);
                break;
            case 5:
                //fantasma_ordenar(array,QTY,0);
                break;
            case 6:
              //  fantasma_mostrarDebug(array,QTY);
                break;
        }

    }while(menu != 9);

    return 0;
}
